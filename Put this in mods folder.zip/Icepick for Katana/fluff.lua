-- i dont really know how lua works so i just stole and modified this whole thing from the "icepick animations for buzzer" mod if u didnt already notice.
Hooks:PostHook(BlackMarketTweakData, "_init_melee_weapons", "buzzer_icepick_anim_mod", function(self, params)

    -- changes the animation
	self.melee_weapons.sandsteel.anim_global_param = "melee_machete"
end)